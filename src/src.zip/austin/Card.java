/* Austin Beauregard
 * Card.java
 * Oct 22, 2014
 * Contains all constructors, fields, and methods for Cards, to be used in Memory.java. 
 */
package austin;

public class Card {
// All fields and methods written by Austin. 
	private boolean faceup = false;
	private boolean matched = false;
	private static int deckCount = 0;
	private String shape = "triangle";
	
	// Many methods below set to public because Card.java is in different package from Card.java.
	public Card(int newShape){ 
		setShape(newShape);
		deckCount++;
	}
	public boolean getFaceUp(){
		return faceup;
	}
	public void setFaceUp(){
		faceup=true;
	}
	public void setFaceDown(){
		faceup=false;
	}
	public boolean getMatched(){
		return matched;
	}
	public void setMatched(){
		matched = true;
	}
	public int getDeckCount(){
		return deckCount;
	}
	public String getShape(){
		return shape;
	}
	
	void setShape(int newShape){
		switch (newShape){
		case 1 : shape = "triangle"; break;
		case 2 : shape = "circle"; break;
		case 3 : shape = "square"; break;
		case 4 : shape = "rectangle"; break;
		case 5 : shape = "star"; break;
		case 6 : shape = "diamond"; break;
		case 7 : shape = "pentagon"; break;
		case 8 : shape = "hexagon"; break;
		case 9 : shape = "octagon"; break;
		case 10 : shape = "smiley face"; break;
		case 11 : shape = "heptagon"; break;
		case 12 : shape = "nonagon"; break;
		case 13 : shape = "undecagon"; break;
		case 14 : shape = "dodecagon"; break;
		case 15 : shape = "stick figure"; break;
		}
	}
}
